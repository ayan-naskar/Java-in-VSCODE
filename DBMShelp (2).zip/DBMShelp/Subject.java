import java.util.ArrayList;
import java.util.HashSet;

public class Subject {
    public class Names {
        static String firstName[] = {"PCC","PEC","EOC"};
        static String secondName[] = {"CS","IT","SS"};
        static String thirdName[] = {"601","602","602C","601B","603A"};
        public static String getName(){
            String f=firstName[(int)(Math.random()*3)];
            String l=secondName[(int)(Math.random()*3)];
            String r=thirdName[(int)(Math.random()*5)];
            String s[]=new String[3];
            s[0]=f;
            s[1]=l;
            s[2]=r;
            return f+"-"+l+r;
        }
    }
    static String[] subject={"Computer Sciences",
        "Logic",
        "Mathematics",
        "Statistics",
        "Systems Science",
        "Agriculture",
        "Architecture and Design",
        "Business",
        "Divinity",
        "Education",
        "Engineering",
        "Environmental Studies and Forestry",
        "Family and Consumer Science",
        "Health Sciences",
        "Human Physical Performance and Recreation",
        "Journalism, Media Studies and Communication",
        "Law",
        "Library and Museum Studies",
        "Military Sciences",
        "Public Administration",
        "Social Work",
        "Transportation",
        "Chemistry",
        "Earth Sciences",
        "Life Sciences",
        "Physics",
        "Space Sciences"};
    public static void main(String[] args) {
        HashSet<String> set = new HashSet<>();
        HashSet<String> set2 = new HashSet<>();
        ArrayList<String> list = new ArrayList<>();
        for(int i=0;i<25;i++){
            System.out.print("insert into Subject values ('");
            while(true){
                String s = Names.getName();
                if(set.contains(s)) continue;
                System.out.print(s+"', '");
                list.add(s);
                break;
            }
            while(true){
                String s = subject[(int)(Math.random()*26)];
                if(set2.contains(s)) continue;
                System.out.println(s+"');");
                break;
            }
        }
        System.out.println("\n\n\n\n\n");
        Fac_Sub.doit(list);
        System.out.println("\n\n\n\n\n");
        Marks.doit(list);
    }
}

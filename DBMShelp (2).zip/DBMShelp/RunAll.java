public class RunAll {
    public static void main(String[] args) {
        Student.main(new String[0]);
        System.out.println("\n\n\n\n\n");
        Department.main(new String[0]);
        System.out.println("\n\n\n\n\n");
        Faculty.main(new String[0]);
        System.out.println("\n\n\n\n\n");
        Subject.main(new String[0]);
    }
}
